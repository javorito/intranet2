        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="../PanelA.php">Inicio</a></li>
            <li><a href="../admin/permisos.php">Usuarios</a></li>
            <li><a href="Sedes.php">Sedes</a></li>
            <li><a href="#">Reportes</a></li>
          </ul>
<!--           <ul class="nav nav-sidebar">
            <li><a href="">Nav item</a></li>
            <li><a href="">Nav item again</a></li>
          </ul> -->
        </div>
